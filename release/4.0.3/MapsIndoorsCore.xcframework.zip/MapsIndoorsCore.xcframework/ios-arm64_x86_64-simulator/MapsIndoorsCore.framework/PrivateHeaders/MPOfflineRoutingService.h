//
//  MPOfflineRoutingService.h
//  MapsIndoors
//
//  Created by Daniel Nielsen on 23/11/2017.
//  Copyright © 2017 MapsPeople A/S. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPRoutingServiceInterface.h"


#pragma mark - [INTERNAL - DO NOT USE]

/// > Warning: [INTERNAL - DO NOT USE]
@interface MPOfflineRoutingService : NSObject <MPRoutingServiceInterface>

@end
